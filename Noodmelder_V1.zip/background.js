// De URL van jouw Google Web App
const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbw_rHfhOKWBJeEkKVzA4EiYYuJWSZ70xGwqEbrJFoeUkq_UFMVrV3IyPOXG3iyE51Q/exec';

// Timer instellen: Elke 30 seconden checken (0.5 minuten)
chrome.alarms.create("statusCheck", { periodInMinutes: 0.5 });

// Wanneer de timer afgaat of de extensie opstart
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "statusCheck") {
    controleerStatus();
  }
});

// Ook direct checken bij installatie of browserstart
chrome.runtime.onInstalled.addListener(() => controleerStatus());
chrome.runtime.onStartup.addListener(() => controleerStatus());

async function controleerStatus() {
  try {
    // We voegen een timestamp toe om te voorkomen dat Chrome een oude versie 'cached'
    const fetchUrl = `${GOOGLE_SCRIPT_URL}?t=${Date.now()}`;
    
    // Google Scripts vereisen 'follow' voor redirects
    const response = await fetch(fetchUrl, { method: 'GET', redirect: 'follow' });
    const data = await response.json();
    
    if (data.alarm === true) {
      toonMelding(data.bericht);
    } else {
      verwijderMelding();
    }
  } catch (error) {
    console.error("Fout bij ophalen status:", error);
  }
}

function toonMelding(tekst) {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      // Alleen op echte websites injecteren, niet op systeem-pagina's
      if (tab.url && tab.url.startsWith("http")) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (msg) => {
            // Check of de melding er al staat om flikkeren te voorkomen
            if (!document.getElementById('nood-overlay')) {
              const div = document.createElement('div');
              div.id = 'nood-overlay';
              div.innerHTML = `
                <div style="padding: 50px; border: 15px solid white; border-radius: 20px; max-width: 80%;">
                  <h1 style="font-size: 80px; margin: 0; text-transform: uppercase;">⚠️ NOODGEVAL</h1>
                  <hr style="border: 2px solid white; margin: 30px 0;">
                  <p style="font-size: 45px; line-height: 1.2;">${msg}</p>
                </div>
              `;
              Object.assign(div.style, {
                position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh',
                backgroundColor: '#b30000', color: 'white', zIndex: '2147483647',
                display: 'flex', justifyContent: 'center', alignItems: 'center',
                textAlign: 'center', fontFamily: 'Arial, sans-serif', fontWeight: 'bold'
              });
              document.body.appendChild(div);
              document.body.style.overflow = 'hidden'; // Voorkom scrollen
            } else {
              // Update alleen de tekst als de overlay al bestaat
              const p = document.querySelector('#nood-overlay p');
              if (p && p.innerText !== msg) p.innerText = msg;
            }
          },
          args: [tekst]
        }).catch(() => { /* Negeer fouten op beveiligde tabs */ });
      }
    });
  });
}

function verwijderMelding() {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.url && tab.url.startsWith("http")) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const overlay = document.getElementById('nood-overlay');
            if (overlay) {
              overlay.remove();
              document.body.style.overflow = 'auto'; // Scrollen weer aanzetten
            }
          }
        }).catch(() => {});
      }
    });
  });
}